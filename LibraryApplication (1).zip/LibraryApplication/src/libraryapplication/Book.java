/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraryapplication;

/**
 *
 * @author BWWAINAINA
 */
public class Book {
    
     public void displaybook(){} 
 
    private String title;
    private String author1;
    private String author2;
    private String type;
    private boolean borrowed;

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the author
     */
//    public String getAuthor() {
//        return author;
//    }
//
//    /**
//     * @param author the author to set
//     */
//    public void setAuthor(String author) {
//        this.author = author;
//    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the borrowed
     */
    public boolean isBorrowed() {
        return borrowed;
    }

    /**
     * @param borrowed the borrowed to set
     */
    public void setBorrowed(boolean borrowed) {
        this.borrowed = borrowed;
    }

    /**
     * @return the author1
     */
    public String getAuthor1() {
        return author1;
    }

    /**
     * @param author1 the author1 to set
     */
    public void setAuthor1(String author1) {
        this.author1 = author1;
    }

    /**
     * @return the author2
     */
    public String getAuthor2() {
        return author2;
    }

    /**
     * @param author2 the author2 to set
     */
    public void setAuthor2(String author2) {
        this.author2 = author2;
    }
  

}
    



