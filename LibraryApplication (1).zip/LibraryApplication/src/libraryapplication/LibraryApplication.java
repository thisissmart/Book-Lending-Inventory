/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraryapplication;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;


public class LibraryApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
    Book book1=new Book();
    book1.setTitle("Designing Secure Systems");
    book1.setAuthor1("Bob Smith");
    book1.setType("Book");
    
    Book book2=new Book();
    book2.setTitle("Web Design Unleashed");
    book2.setAuthor1("Jake Sims");
    book2.setAuthor2("Brian John");
    book2.setType("Book");
    
    Book book3=new Book();
    book3.setTitle("Understanding TCP/IP Networks");
    book3.setAuthor1("Laura Daniels");
    book3.setType("Book");
    
    Audiobooks book4=new Audiobooks();
    book4.setTitle("Quiting a Habit in 21 Days");
    book4.setAuthor1("Rose Cole");
    book4.setDuration("90 minutes");

    Borrowing borrowing1=new Borrowing();
    borrowing1.setBook(book1);
    borrowing1.setFine(15F);
    
    Borrowing borrowing2=new Borrowing();
    borrowing2.setBook(book2);
    borrowing2.setFine(15F);
    
    Borrowing borrowing3=new Borrowing();
    borrowing3.setBook(book3);
    
    Borrowing borrowing4=new Borrowing();
    borrowing4.setBook(book4);
   
    System.out.println(java.time.LocalDate.now());
    
    LocalDate CurrentDate=LocalDate.now();
    LocalDate borrowDate1=LocalDate.of(2019,Month.FEBRUARY,2);
    LocalDate returnDate1=LocalDate.of(2019, Month.FEBRUARY,23);
    borrowing1.setBorrowDate(borrowDate1);
    borrowing1.setReturnDate(returnDate1);
    
    
    LocalDate borrowDate2=LocalDate.of(2019,Month.MARCH,13);
    LocalDate returnDate2=LocalDate.of(2019, Month.APRIL,3);
    borrowing2.setBorrowDate(borrowDate2);
    borrowing2.setReturnDate(returnDate2); 
    
    LocalDate borrowDate3=LocalDate.of(2018,Month.FEBRUARY,2);
    LocalDate returnDate3=LocalDate.of(2018, Month.FEBRUARY,5);
    borrowing3.setBorrowDate(borrowDate3);
    borrowing3.setReturnDate(returnDate3);
   
    LocalDate borrowDate4=LocalDate.of(2018,Month.FEBRUARY,2);
    LocalDate returnDate4=LocalDate.of(2018, Month.FEBRUARY,5);
    borrowing4.setBorrowDate(borrowDate4);
    borrowing4.setReturnDate(returnDate4);
    
    
    borrowing1.borrow();
    borrowing2.borrow();
//    borrowing3.borrow();
//    borrowing4.borrow();
    
    
    
    ArrayList<Borrowing>borrowings=new ArrayList<>();
    borrowings.add(borrowing1);
    borrowings.add(borrowing2);
    borrowings.add(borrowing3);
    borrowings.add(borrowing4);
    
     ArrayList<Book>books=new ArrayList<>();
     books.add(book1);
     books.add(book2);
     
    
     
    Reports.displayBorrowings(borrowings);
    Reports.displayBooks(borrowings);
    Reports.borrowedBooks(borrowings);
    Reports.totalFineAmount(borrowings);
    }
    
}

