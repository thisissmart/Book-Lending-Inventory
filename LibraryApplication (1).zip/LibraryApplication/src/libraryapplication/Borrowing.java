/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraryapplication;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Borrowing {
    private int trackingId;

    private Book book;
    private Audiobooks audiobooks;
    private LocalDate borrowDate;
    private final LocalDate currentDate;
    private LocalDate returnDate;
    private float totalAmount;
    private float fine;

    public Borrowing() {
        this.currentDate = LocalDate.now();
    }
    public void borrow() {
        long difference=ChronoUnit.DAYS.between(getReturnDate(),LocalDate.now() );
            setTotalAmount(difference * getFine());

            getBook().setBorrowed(true);
          
}

    /**
     * @return the trackingId
     */
    public int getTrackingId() {
        return trackingId;
    }

    /**
     * @param trackingId the trackingId to set
     */
    public void setTrackingId(int trackingId) {
        this.trackingId = trackingId;
    }

    /**
     * @return the user
     */
    
    /**
     * @return the book
     */
    public Book getBook() {
        return book;
    }

    /**
     * @param book the book to set
     */
    public void setBook(Book book) {
        this.book = book;
    }

    

    /**
     * @return the totalAmount
     */
    public float getTotalAmount() {
        return totalAmount;
    }

    /**
     * @param totalAmount the totalAmount to set
     */
    public void setTotalAmount(float totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * @return the fine
     */
    public float getFine() {
        return fine;
    }

    /**
     * @param fine the fine to set
     */
    public void setFine(float fine) {
        this.fine = fine;
    }

    /**
     * @return the borrowDate
     */
    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    /**
     * @return the returnDate
     */
    public LocalDate getReturnDate() {
        return returnDate;
    }

    /**
     * @param borrowDate the borrowDate to set
     */
    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }

    /**
     * @param returnDate the returnDate to set
     */
    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    /**
     * @return the audiobooks
     */
    public Audiobooks getAudiobooks() {
        return audiobooks;
    }

    /**
     * @param audiobooks the audiobooks to set
     */

}
