/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraryapplication;


import java.util.ArrayList;


public class Reports {
    
    public static void displayBorrowings(ArrayList<Borrowing>borrowings){
        System.out.println("=====================");
        System.out.println("LIBRARY CATALOGUE");
        System.out.println("=====================");
        
        
        for (Borrowing borrowing : borrowings){
            String author=borrowing.getBook().getAuthor1();
            String author2=borrowing.getBook().getAuthor2();
            String title=borrowing.getBook().getTitle();
            String type=borrowing.getBook().getType();
           
     if(borrowing.getBook().getAuthor1().equalsIgnoreCase("jake sims")){
           System.out.println("[title] " + title +"\n" + "[author] " + author +"\n" + "[author] " + author2 +"\n" +"[type] "+ type +" \n");
        } 
     else{
          System.out.println("[title] " + title +"\n" + "[author] " + author +"\n" + "[type] "+ type +" \n");
     }
        }
    }
         public static void displayBooks(ArrayList<Borrowing>borrowings){
         System.out.println("=====================");
          System.out.println("LIST OF AUDIO BOOKS");
           System.out.println("=====================");
           
            for (Borrowing borrowing : borrowings){
            String author=borrowing.getBook().getAuthor1();
            String title=borrowing.getBook().getTitle();
            String type=borrowing.getBook().getType();
         
          
             if(borrowing.getBook().getType().equalsIgnoreCase("audiobooks")){
                 
               //  borrowing.getAudiobooks.getDuration();
                  String time=((Audiobooks)borrowing.getBook()).getDuration();
                //  System.out.println( time);
                   System.out.println("[title] " + title +"\n" + "[author] " + author +"\n" + "[duration] " + time +"\n");
                  
             }
        }
    }
         
         public static void borrowedBooks(ArrayList<Borrowing>borrowings){
        System.out.println("=====================");
        System.out.println("LIST OF BORROWED BOOKS");
        System.out.println("======================");
        
        for (Borrowing borrowing : borrowings){
           
            String title=borrowing.getBook().getTitle();
           String date = borrowing.getBorrowDate().toString();
           String date1 = borrowing.getReturnDate().toString();
           
            
            if(borrowing.getBook().isBorrowed()){
                System.out.println("");
                System.out.println("[title] " + title +"\n" + "[borrowed date]" + date +"\n" + "[due date]" + date1);
            }
        }
    }
         
         
         public static void totalFineAmount (ArrayList<Borrowing> borrowings){
        System.out.println("=====================");
        System.out.println("LIST OF OVERDUE ITEMS");
        System.out.println("======================");
        float totalAmount = 0f;
        
        for (Borrowing borrowing : borrowings){
            
           String title=borrowing.getBook().getTitle();
           String date = borrowing.getBorrowDate().toString();
           String date1 = borrowing.getReturnDate().toString();
           
           float fine = borrowing.getTotalAmount();
           totalAmount +=fine;
           
           if(borrowing.getBook().getAuthor1().equalsIgnoreCase("Bob Smith")){
               System.out.println("");
               System.out.println("[title] " + title +"\n" + "[borrowed date]" + date +"\n" + "[due date]" + date1 + "\n" + "[fine] Ksh" + totalAmount);
            
            }
        }
    }
}



