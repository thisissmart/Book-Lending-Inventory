/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libraryapplication;

/**
 *
 * @author snderitu
 */
public class Audiobooks extends Book{
    
    @Override
  public void displaybook(){}
   String duration;
    String title;
    String author;
    boolean borrowed;

    /**
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * @param duration the duration to set
     */
   
    public void setDuration(String duration) {
        this.duration = duration;
    }
    @Override
    public String getType() {
        return "Audiobooks";
    }
}

